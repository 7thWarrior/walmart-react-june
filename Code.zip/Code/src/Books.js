import React from "react";
import "./Books.css";

class Books extends React.Component
{
    render()
    {
        var p1Style={fontSize:"24px",backgroundColor:"pink"};
        // mandatory method
        // return the virtual DOM
        return (
            <div>
                <h1>Books Component</h1>
                <p id="p1" style={p1Style}>Alchemist</p>
            </div>
        );
    }
}

export default Books;
