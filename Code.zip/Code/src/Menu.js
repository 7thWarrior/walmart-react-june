import React, { Component } from 'react';

import {Link} from 'react-router-dom'
import "./Menu.css";
export default class Menu extends Component {
  render() {
    return (
      <div className='container-fluid'>
          <ul>
              <li>
                  <Link to="/products">Products</Link>
              </li>
              <li>
                  <Link to="/users">Users</Link>
              </li>
              <li>
                  <Link to="/cart">Cart</Link>
              </li>
          </ul>
      </div>
    )
  }
}
