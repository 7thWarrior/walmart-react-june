import React, { Component } from 'react';

import { Route, Switch,Redirect } from "react-router-dom"
import Products from './Products';
import Users from './Users';
import Cart from "./Cart";
import Details from './Details';

export default class Home extends Component {
    render() {
        return (
            <div>
                <Switch>
                    <Redirect path="/" to="/products" exact component={Products}></Redirect>
                    <Route path="/products" component={Products}></Route>
                    <Route path="/users" component={Users}></Route>
                    <Route path="/cart" component={Cart}></Route>
                    <Route path="/details/:pId" component={Details}></Route>
                    <Route path="**"
                        render={
                            (props) => {
                                return (<div>Page Not Found</div>)
                            }
                        }
                    ></Route>
                </Switch>
            </div>
        )
    }
}
