import logo from './logo.svg';
import './App.css';
import Footer from './Footer';
import { Header } from './Header';
import React from 'react';
import Products from './Products';
import Users from './Users';
import Menu from './Menu';
import Home from "./Home"
import { BrowserRouter } from "react-router-dom";

function App() {

  return (
    <React.Fragment>
      <Header></Header>
      <BrowserRouter>
        <Menu></Menu>
        <Home></Home>
        
      </BrowserRouter>
      <Footer></Footer>
    </React.Fragment>
  );
}

export default App;
