import React, { Component } from 'react'

export default class Cart extends Component {
  render() {
      console.log("Cart Arr in Cart Component",this.props.cartArr);
    return (
      <div>Cart Component</div>
    )
  }
}
