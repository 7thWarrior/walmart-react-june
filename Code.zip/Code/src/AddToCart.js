import React, { Component } from 'react'

export default class AddToCart extends Component {
    constructor(props) {
        super(props);
        this.state = { quantitySelected: 1 ,companyName:this.props.companyName};

    }
    changeQuantityEventHandler = (modifyString) => {
        if (modifyString == "dec") {
            /*
            var temp=this.state.quantitySelected-1;
            this.setState({quantitySelected:temp});
            */
            if (this.state.quantitySelected > 1) {
                this.setState((prevState) => {
                    return (
                        {
                            quantitySelected: prevState.quantitySelected - 1
                        }
                    )
                });
            }
        }
        else {
            if (this.state.quantitySelected < this.props.selectedObject.quantity) {
                this.setState((prevState) => {
                    return (
                        {
                            quantitySelected: prevState.quantitySelected + 1
                        }
                    )
                })
            }
        }
    }
    cancelInAddToCartEventHandler=()=>{
        this.props.onCancel();// triggering the event;
    }
    buyEventHandler=()=>{
        var cartObj={...this.props.selectedObject,quantitySelected:this.state.quantitySelected};
        // trigger the event onBuyConfirm
        this.props.onBuyConfirm(cartObj);
    }
    render() {
        console.log("Props in AddToCart", this.props);
        var { selectedObject } = this.props;// copy
        //var selectedObject= this.props.selectedObject;//ref

        return (
            <div className='bg-warning h1 container-fluid'>
                <div className='row'>
                    <h1 className='col-4 offset-4 '>AddToCart Component of {this.state.companyName}</h1>
                </div>
                <div className='row'>
                    <div className='col-4 offset-4'>
                        <div key={selectedObject.productId} className="card bg-primary text-warning m-2 p-2" style={{ width: "18rem" }}>
                            <img src={selectedObject.imgUrl} alt={selectedObject.productName} className="card-img-top" />
                            <div className="card-body">
                                <h1 className="card-title">{selectedObject.productName}</h1>
                                <p className="card-text">Quantity: {selectedObject.quantity}</p>
                                <p className="card-text">Price: {selectedObject.price}</p>
                                <input type="button"
                                disabled={this.state.quantitySelected <=1}
                                 value="-" className='btn btn-danger m-2 text-warning' onClick={this.changeQuantityEventHandler.bind(this, "dec")} />

                                <span className="card-text"> {this.state.quantitySelected} </span>

                                <input type="button" disabled={this.state.quantitySelected >= this.props.selectedObject.quantity}
                                 value="+" className='btn btn-danger m-2 text-warning' onClick={this.changeQuantityEventHandler.bind(this, "inc")} />

                                 <br/>
                                 <input type="button" value="Buy" className='btn btn-warning m-2' onClick={this.buyEventHandler}/>
                                 <input type="button" value="Cancel" className='btn btn-danger m-2' onClick={this.cancelInAddToCartEventHandler}/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        )
    }
}
