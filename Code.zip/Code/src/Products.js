import React from "react";
import AddToCart from "./AddToCart";
import Cart from "./Cart";

class Products extends React.Component
{
    companyName="Walmart";
    constructor()
    {
        super();
        // scope of this -- class scope
        this.cancelEventHandler=this.cancelEventHandler.bind(this);
        this.state={
            showAddToCart:false,
            selectedObj:null,
            cartArr:[],
            productsArr:[
                {productId:"P101",productName:"Apple Iphone",description:"",price:145678,quantity:66,imgUrl:"./images/iphone.jpg"},
                {productId:"P102",productName:"Nokia",description:"",price:4567,quantity:1,imgUrl:"./images/nokia.jpg"},
                {productId:"P103",productName:"One plus",description:"",price:45678,quantity:10,imgUrl:"./images/oneplus9.jpg"},
                {productId:"P104",productName:"Samsung note 9",description:"",price:67890,quantity:5,imgUrl:"./images/samsung.jpg"},
            ]
        }
        
    }
    addToCartEventHandler=(selectedObj)=>{
        // lexical scope of this operator; scope of the class
        console.log("INside faf",this.companyName);//walmart
        console.log("Button clicked on ",selectedObj.productName);

        /* logically -- correct --yes ; react -- correct -- no
        this.state.showAddToCart=true;
        this.state.selectedObj=selectedObj;
        */

        this.setState({showAddToCart:true,selectedObj:selectedObj},()=>{
            console.log("Show Add to cart",this.state.showAddToCart);
        })

        
    }
    cancelEventHandler=function(){
        // this -- undefined
        //console.log("this",this);
        console.log("Inside the anonymous fn",this.companyName);//error with no bind
    }
    cancelEventHandler=()=>{
        alert("Message received from the child AddToCart");
        this.setState({showAddToCart:false});
    }

    onBuyConfirmEventHandler=(cartObj)=>{
        console.log("Cart obj in Products Component",cartObj);
        this.setState({showAddToCart:false,selectedObj:null});
        // modify the quantity based on user purchase
        var tempArr=[...this.state.productsArr];
        var pos= tempArr.findIndex(item => item.productId === cartObj.productId);
        tempArr[pos].quantity-=cartObj.quantitySelected;
        this.setState({productsArr:tempArr,cartArr:[...this.state.cartArr,cartObj]});
    }
    render()
    {
        let productsArr=this.state.productsArr;
        // dynamic generation
        var cardArr=productsArr.map(item=>{
            return (
                <div key={item.productId} className="card col-4 bg-primary text-warning m-2 p-2" style={{width:"18rem"}}>
                <img src={item.imgUrl} alt={item.productName} className="card-img-top"/>
                <div className="card-body">
                    <h1 className="card-title">{item.productName}</h1>
                    <p className="card-text">Quantity: {item.quantity}</p>
                    <p className="card-text">Price: {item.price}</p>
                    <input type="button" value="Add To Cart" className="btn btn-success"
                    onClick={this.addToCartEventHandler.bind(this,item)}
                    />

                    <input type="button" value="Details" className="btn btn-success m-2"
                    onClick={ ()=>{
                            this.props.history.push("/details/"+item.productId);
                        }
                    }
                    />

                </div>
            </div>
           
            );
        })

        var cardArr2=productsArr.map(item=>{
            return (
                <div key={item.productId} className="card col-4 bg-primary text-warning m-2 p-2" style={{width:"18rem"}}>
                <img src={item.imgUrl} alt={item.productName} className="card-img-top"/>
                <div className="card-body">
                    <h1 className="card-title">Out of stock</h1>
                    
                </div>
            </div>
           
            );
        })
        // mandatory method
        // return the virtual DOM
        return (
            <div>
                <h1>Products Component</h1>
                <div className="container-fluid">
                    <div className="row">
                      {cardArr}
                     
                    </div>
                    <div className="row">
                        {this.state.showAddToCart && 
                        <AddToCart 
                        selectedObject={this.state.selectedObj} 
                        companyName="walmart"
                        onCancel={this.cancelEventHandler}
                        onBuyConfirm={this.onBuyConfirmEventHandler}
                        ></AddToCart>}
                      
                    </div>
                   
                </div>
            </div>
        );
    }
}

export default Products;
/*
  {this.state.showAddToCart ? <AddToCart></AddToCart>:null}


render() -- return the virtual DOM ;built Real DOM
click on button -- changes to the data and this should reflect in the UI
two data binding -- NO

call render method again(return a new virtual DOM and not making changes to the previous virtual DOM)

constructor -- called implicitly when an object is created, 
--initialisation of object members; 
--called only once for a particular object
-- cannot be called explicitly without creating an instance
--first method to be called when object is called
--lifecycle method of component

render -- 
-- returns the virtual DOM
-- called implicitly after the constructor during the mount of component
-- lifecycle method of compoenent
-- cannot be called explicitly
-- setState() calls will implicitly call the render

state 
-- changes to state makes calls to the render method again
-- state can be changed by calling setState()
-- object which is initialised in the constructor
-- mutable local data of the component
-- should change the state only using setState()


setState()
-- update the state and call the render method again
-- async function
-- takes in 2 params 
-- first param -- obj or function
-- second param -- function (callback function)
-- batched together and executed

-- first param obj -- new obj merged with the state 
-- first param function -- function should return an obj which will be merged with the state; 
    function will get reference to old state

-- second param 
-- function will be executed on completion of setState async operation


i=10;// assigning a new value
i=i+10;// incrementation


-- diffing algorithm -- 2 virtual DOM
make changes to the state -- 2 values to compare
never make changes to the state;


i=10;
SOP(i);//10
i=20;
SOP(i);//20

parent to child communication
-- use attributes/ properties

<a id ="a1" href="https://www.walmart.com">Go To walmart </a>
<img id="img" src="" href />

props -- immutable data
-- data sent from the parent to that component
-- have something else; routing information


Products -- mounted
1. constructor of Products
2. render of Products (showAddToCart -- false; AddTo Cart will not be mounted)

3. user click on addtocart button
4. event handler will be executed
5. button clicked will be logged
6. setState will be called
-- 6.a state will be updated
-- 6.b render Of Products will be called(showAddToCart -- true; AddToCart will be mounted)
----- 6.b.a AddToCart constructor 
----- 6.b.a AddToCart render
7. setState is completed; callback of setState is executed
-- Log the addToCart value as true

child to parent communication

cancel button in the AddToCart should modify the showAddToCart in Products

--events

<input type="button" value="Calculate"  onClick={this.calculateFunc} />

Input tag is written in Component A;
calculateFunc written/ member method of componentA
user clicks on button -- event  gets triggered which will call the event handler;

<AddToCart onCancel={cancelEventHandler}>
AddToCart element -- component A/Products
cancelEventHandler -- member of component A/Products
trigger the user defined event -- AddToCart


var func1=function f1(){
    console.log("hello");
}



f1();//error
func1();

function f1()
{
    console.log("hello");
}

var func1=f1;



*/