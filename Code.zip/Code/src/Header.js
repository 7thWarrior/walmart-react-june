import React from "react";

export class Header extends React.Component {
    render() {
        let logoImgUrl="./images/walmartLogo.jpg";
    
        return (
            <div className='container-fluid'>
                <div className="bg-warning text-primary text-uppercase row align-items-center">
                <img className='col-4 img-fluid' style={{height:"100px"}} src={logoImgUrl} alt="Walmart logo" />
                    <h1 className='col-8 text-center'>Walmart</h1>
                   
                </div>
            </div>

        );
    }
}

