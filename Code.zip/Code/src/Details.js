import React, { Component } from 'react'

export default class Details extends Component {
  render() {
      console.log("Props in detail component",this.props)
    return (
      <div>Details Component of Product with Product Id : {this.props.match.params.pId}</div>
    )
  }
}
