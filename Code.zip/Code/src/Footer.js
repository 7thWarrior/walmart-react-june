import React, { Component,useState } from 'react'

function Footer()  {
  console.log("Hello")
  var counter=0;
  var [numberOfVisitors,setNumberOfVisitors]=useState(0);
  // return the virtual DOM
  const clickEventHandler=()=>{
    console.log("Inside the event handler within  the footer");
    counter+=1;
    console.log("Counter : ",counter)
  }
  const nOfVclickEventHandler=()=>{
    setNumberOfVisitors(numberOfVisitors+1);
    //update the numberOfVisitors; return the virtual DOM; call the function again; maintain or remember the old state value
    // use state hook maintains the state across the updates to the component
  }
  return(
    <div>
      <p>Counter:{counter}</p>
      <input type="button" value="Increment counter" onClick={clickEventHandler}/>
      <br/>
      <p>Number of Visitors: {numberOfVisitors}</p>
      <input type="button" value="Increment number of Visitors" onClick={nOfVclickEventHandler}/>
    </div>
  );
}
export default Footer