import React, { Component } from 'react'
import axios from "axios";

export default class Users extends Component {
    constructor()
    {
        super();
    }
    componentDidMount()
    {
        /* called after the render
        after the DOM has been loaded
        called implicitly only once
        talk to the server
        3rd party subscriptions

        */
       var serverUrl="https://jsonplaceholder.typicode.com/posts"
       axios.get(serverUrl)
       .then((response)=>{
           console.log(response)
       })
       .catch((err)=>{
           console.log("Error",err)
       })
    }
  render() {
    return (
      <div>Users Component</div>

    )
  }
}
